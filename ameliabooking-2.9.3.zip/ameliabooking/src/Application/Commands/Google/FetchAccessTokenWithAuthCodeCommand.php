<?php

namespace AmeliaBooking\Application\Commands\Google;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class FetchAccessTokenWithAuthCodeCommand
 *
 * @package AmeliaBooking\Application\Commands\Google
 */
class FetchAccessTokenWithAuthCodeCommand extends Command
{

}
