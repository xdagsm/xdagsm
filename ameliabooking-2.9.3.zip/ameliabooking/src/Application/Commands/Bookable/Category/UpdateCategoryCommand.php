<?php

namespace AmeliaBooking\Application\Commands\Bookable\Category;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateCategoryCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Category
 */
class UpdateCategoryCommand extends Command
{

}
