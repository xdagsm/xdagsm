<?php

namespace AmeliaBooking\Application\Commands\User\Provider;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdateProviderCommand
 *
 * @package AmeliaBooking\Application\Commands\User\Provider
 */
class UpdateProviderCommand extends Command
{

    /**
     * UpdateProviderCommand constructor.
     *
     * @param $args
     */
    public function __construct($args)
    {
        parent::__construct($args);
    }
}
