<?php

namespace AmeliaBooking\Domain\Repository\Bookable\Service;

use AmeliaBooking\Domain\Repository\BaseRepositoryInterface;

/**
 * Interface CategoryRepositoryInterface
 *
 * @package AmeliaBooking\Domain\Repository\Bookable\Service
 */
interface CategoryRepositoryInterface extends BaseRepositoryInterface
{

}
