<?php

namespace AmeliaBooking\Domain\Entity\Bookable\Service;

use AmeliaBooking\Domain\Entity\Bookable\AbstractCategory;

/**
 * Class Category
 *
 * @package AmeliaBooking\Domain\Entity\Bookable\Service
 */
class Category extends AbstractCategory
{

}
